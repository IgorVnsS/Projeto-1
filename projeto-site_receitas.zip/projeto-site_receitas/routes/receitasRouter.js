var express = require('express');
var router = express.Router();
const { listar, busca, receita } = require('../controllers/receitasController');

router.get('/', listar);
router.get('/busca', busca);
router.get('/:id', receita);

module.exports = router;