const receitas = {
    1: {
        id: 1,
        titulo: 'Bolo de Chocolate',
        ingredientes: ['2 xícaras de farinha', '1 xícara de açúcar', '3 ovos', '1/2 xícara de óleo', '1 xícara de chocolate em pó', '1 xícara de leite', '1 colher de fermento em pó'],
        instrucoes: ['Pré-aqueça o forno a 180°C.', 'Misture todos os ingredientes.', 'Despeje a massa em uma forma untada e asse por 40 minutos.'],
        imagem: 'https://static.itdg.com.br/images/640-440/3b03a942ab534200a0a80eb324828ccb/246606-postprocess-71802381-1893-4fbe-b302-726bfca18774.jpg'
    },
    2: {
        id: 2,
        titulo: 'Bolo de Cenoura',
        ingredientes: ['3 cenouras médias raladas', '4 ovos', '1 xícara de óleo', '2 xícaras de açúcar', '2 1/2 xícaras de farinha de trigo', '1 colher de sopa de fermento em pó'],
        instrucoes: ['No liquidificador, bata as cenouras, os ovos e o óleo.', 'Em uma tigela, misture o açúcar, a farinha e o fermento.', 'Adicione a mistura do liquidificador na tigela e mexa bem.', 'Coloque em uma forma untada e leve ao forno pré-aquecido a 180°C por cerca de 40 minutos.'],
        imagem: 'https://bolosparavender.com/wp-content/uploads/2019/11/bolo-de-cenoura-cremoso-com-leite-condensado-750x750.jpg'
    },
    3: {
        id: 3,
        titulo: 'Mousse de Maracujá',
        ingredientes: ['1 lata de leite condensado', '1 lata de creme de leite', '1 xícara de suco de maracujá concentrado', 'Polpa de 1 maracujá (opcional para decorar)'],
        instrucoes: ['No liquidificador, bata o leite condensado, o creme de leite e o suco de maracujá até obter uma mistura homogênea.', 'Despeje a mistura em taças ou em uma tigela grande.', 'Leve à geladeira por pelo menos 3 horas antes de servir.', 'Decore com a polpa de maracujá antes de servir, se desejar.'],
        imagem: 'https://static.itdg.com.br/images/640-440/8231acb174ba2e6a4b4a61145e48eea7/249008-shutterstock-1907121220.jpg'
    },
    4: {
        id: 4,
        titulo: 'Brownie',
        ingredientes: ['1 xícara de manteiga', '2 xícaras de açúcar', '4 ovos', '1 xícara de farinha de trigo', '1 xícara de cacau em pó', '1 colher de chá de essência de baunilha', '1 pitada de sal'],
        instrucoes: ['Pré-aqueça o forno a 180°C.', 'Derreta a manteiga e misture com o açúcar.', 'Adicione os ovos, um de cada vez, mexendo bem após cada adição.', 'Misture a farinha, o cacau em pó e o sal.', 'Adicione a essência de baunilha e mexa até ficar homogêneo.', 'Despeje a massa em uma forma untada e asse por cerca de 25-30 minutos.'],
        imagem: 'https://static.itdg.com.br/images/360-240/9e621f4e0b36756979fda3f87f8279a5/340593-original.jpg'
    }
};
const nao_encontrado = 'Nenhum resultado encontrado.';

const listar = (req, res) => {
  res.render('receitas/receitas', { title: "Receitas" });
};

const receita = (req, res) => {
  const receitaId = parseInt(req.params.id, 10);
  const receita = receitas[receitaId];
  if (receita) {
    res.render('receitas/receita', { receita });
  } else {
    res.status(404).send('Receita não encontrada');
  }
};

const busca = (req, res) => {
  const receita = req.query.receita.toLowerCase();
  const resultados = Object.values(receitas).filter(r => r.titulo.toLowerCase().includes(receita));
  if (resultados.length > 0) {
    res.render('receitas/busca', { receitas: resultados });
  } else {
    res.render('receitas/busca', { receitas: [], message: nao_encontrado });
  }
};

module.exports = { listar, busca, receita };