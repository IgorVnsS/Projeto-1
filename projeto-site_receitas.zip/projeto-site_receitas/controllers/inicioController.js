const inicio = function(req, res){
    res.render('inicio/paginainicial', {
        title: "Início"
    })
}
  
module.exports = { inicio }